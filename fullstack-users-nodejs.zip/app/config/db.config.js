// credentials
module.exports = {
  HOST: "ziggy.db.elephantsql.com",
  USER: "cxeptapk",
  PASSWORD: "8UF9xAQ52r539-pDZf7TSGLOgMRGONht",
  DB: "cxeptapk",
  PORT: 5432,
  dialect: "postgres",
};
